<section class="status container">
  <h2 class="section-title">Мой статус</h2>
  <p>#яжверстальщик!</p>
</section>
