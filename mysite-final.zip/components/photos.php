<section class="photos container">
  <h2 class="section-title">Мои фотографии</h2>
  <figure>
    <img src="img/photo1.jpg" width="285" height="146" alt="Сайт инструктора Кекса">
    <figcaption>Сайт инструктора Кекса</figcaption>
  </figure>
  <figure>
    <img src="img/photo2.jpg" width="285" height="146" alt="Кекс">
    <figcaption>Кекс</figcaption>
  </figure>
  <figure>
    <img src="img/photo3.svg" width="285" height="146" alt="Новая аватарка">
    <figcaption>Новая аватарка</figcaption>
  </figure>
  <figure>
    <img src="img/photo4.svg" width="285" height="146" alt="Первая глава">
    <figcaption>Первая глава</figcaption>
  </figure>
</section>
