</main>
  <footer class="page-footer page-footer--logo">
    <div class="container">
      <p>© <?= $name ?>, 2020</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
