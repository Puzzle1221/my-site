<section class="quotes container">
  <h2 class="section-title">Любимые цитаты</h2>
  <blockquote>
    <p>Плохие программисты думают о коде. Хорошие программисты думают о структурах данных и их взаимосвязях.</p>
    <cite>Линус Торвальдс</cite>
  </blockquote>
  <blockquote>
    <p>Хорошему коту и в феврале март.</p>
    <cite>Кекс</cite>
  </blockquote>
</section>
