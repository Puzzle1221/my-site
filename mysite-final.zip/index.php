<?php
$title = 'Мой сайт';
$name = 'Неопознанный енот';
$image = 'img/unknown-raccoon.svg';
$email = 'enot_neopoznanniy@gmail.com';
$phone = '+79876543210';

require('components/header.php');
require('components/about.php');
require('components/status.php');
require('components/photos.php');
require('components/news.php');
require('components/quotes.php');
require('components/contacts.php');
require('components/footer.php');
